self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4f9654114bd6dfb87923dff5be7dab32",
    "url": "/index.html"
  },
  {
    "revision": "dcf96584e98e7292a406",
    "url": "/static/css/main.ad3f754d.chunk.css"
  },
  {
    "revision": "76a500ba795620850aef",
    "url": "/static/js/2.8c665cec.chunk.js"
  },
  {
    "revision": "41b66b6fd6eecba581340794bb1831be",
    "url": "/static/js/2.8c665cec.chunk.js.LICENSE.txt"
  },
  {
    "revision": "dcf96584e98e7292a406",
    "url": "/static/js/main.3f266899.chunk.js"
  },
  {
    "revision": "df11726cbf66339790ea",
    "url": "/static/js/runtime-main.970cab50.js"
  },
  {
    "revision": "dfc54362fc2b0f7b99a4038b87dd9e64",
    "url": "/static/media/1.dfc54362.png"
  },
  {
    "revision": "2048975925bd8553d8aaa5e1d9d1ffb1",
    "url": "/static/media/2.20489759.png"
  },
  {
    "revision": "dbf82c38432d45de3c1c99f13c8b5fee",
    "url": "/static/media/3.dbf82c38.png"
  },
  {
    "revision": "e671d53961f44185ee61256a0e6f13a5",
    "url": "/static/media/4.e671d539.png"
  },
  {
    "revision": "35bcd06768ffafae4a5721b8f0c4fd8f",
    "url": "/static/media/burger.35bcd067.png"
  },
  {
    "revision": "06277842ccc3f7c2a37085189dacdcbc",
    "url": "/static/media/check-symbol.06277842.svg"
  },
  {
    "revision": "751f84c25a8d1ff159f499cbb9aa5bb7",
    "url": "/static/media/edit.751f84c2.svg"
  },
  {
    "revision": "4fd2ba47b4f59d0a4382a8d81aae85d6",
    "url": "/static/media/kfc.4fd2ba47.png"
  },
  {
    "revision": "60464810e8cfcde7a20fc19284c38a0e",
    "url": "/static/media/mcdac.60464810.png"
  },
  {
    "revision": "1198ed41690cc0974aa8baa0e95ebd1b",
    "url": "/static/media/refresh-button.1198ed41.svg"
  },
  {
    "revision": "4eb05fdd9f3d81f2f81cac5847e25cc9",
    "url": "/static/media/sub.4eb05fdd.png"
  }
]);